% function [d T]=mexEMD(r,c,M,maxIter)
% 
% this function computes the optimal transportation cost between two
% vectors r and c given a cost matrix M. If M is a distance matrix the
% output is a distance itself. In some (rare) cases, the optimality
% condition is not precise enough and the algorithm cycles even though
% optimal optimality was reached. This can happen when the problem is
% highly degenerated. To avoid infinite cycling you can provide a maximum
% number of iterations, it is then recommended to check if the resulting
% transport plan is optimal.
% 
% Required input :
%           -r a n dimensionnal non negative vector which coordinates sum
%           to one
%           -c a m dimensionnal non negative vector which coordinates sum
%           to one
%           -M a nxm cost matrix
%
% Optional input :
%           -maxIter the maximum number of pivot iterations of the simplex algorithm
%
% Output :
%           -d the optimal transportation cost between r and c
%           -T the optimal transporation plan as a nxm matrix. Note that d=<T,M>